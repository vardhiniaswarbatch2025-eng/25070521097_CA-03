import { createRoot } from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import { Provider } from './ctx';
import App from './App';
import './styles.css';
createRoot(document.getElementById('root')).render(<BrowserRouter><Provider><App /></Provider></BrowserRouter>);
